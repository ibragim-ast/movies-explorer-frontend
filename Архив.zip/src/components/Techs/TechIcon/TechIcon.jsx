import "./TechIcon.css";

export default function TechIcon({ title }) {
  return <li className="techs__list-item">{title}</li>;
}
